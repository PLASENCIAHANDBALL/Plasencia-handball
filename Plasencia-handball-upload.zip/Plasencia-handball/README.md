# Plasencia Handball - App completa

Este paquete contiene la app completa lista para subir a GitHub y desplegar en GitHub Pages.

## Contraseña admin por defecto
`PHB-2025!Porterias&Redes#98`

## Pasos para subir a GitHub

1. Descarga y descomprime la carpeta.
2. Entra en tu repo: https://github.com/PLASENCIAHANDBALL/Plasencia-handball
3. Pulsa **Add file → Upload files**.
4. Arrastra **todo el contenido de la carpeta** (los archivos y subcarpetas directamente).
5. Asegúrate de que la rama seleccionada es `main` y pulsa **Commit changes**.
6. Ve a **Actions** y espera a que el flujo **Deploy to GitHub Pages** termine en verde.
7. Tu página pública estará en: `https://plasenciahandball.github.io/Plasencia-handball/`

Si tienes algún error en Actions, copia las últimas líneas del log y pégalas en el chat para que te ayude a corregirlas.
