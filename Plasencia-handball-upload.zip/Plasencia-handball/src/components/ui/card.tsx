import * as React from 'react'
export function Card({className='',...p}:any){return <div className={className} {...p}/>}
export function CardHeader(p:any){return <div {...p}/>}
export function CardContent(p:any){return <div {...p}/>}
export function CardTitle(p:any){return <h3 {...p}/>}
