import * as React from 'react'
export const Textarea = React.forwardRef((props:any, ref:any) => <textarea ref={ref} {...props} />)
