import * as React from 'react'
export function Label(p:any){return <label {...p}/>}
