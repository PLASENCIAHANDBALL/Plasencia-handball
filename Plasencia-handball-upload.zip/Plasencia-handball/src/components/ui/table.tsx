import * as React from 'react'
export function Table(p:any){return <table {...p}/>}
export function TableHeader(p:any){return <thead {...p}/>}
export function TableBody(p:any){return <tbody {...p}/>}
export function TableRow(p:any){return <tr {...p}/>}
export function TableHead(p:any){return <th {...p}/>}
export function TableCell(p:any){return <td {...p}/>}
