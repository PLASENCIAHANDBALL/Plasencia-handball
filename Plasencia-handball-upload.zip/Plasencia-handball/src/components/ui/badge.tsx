import * as React from 'react'
export function Badge(p:any){return <span {...p}/>}
